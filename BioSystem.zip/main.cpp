#define _CRT_SECURE_NO_WARNINGS
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <time.h>
#include <string.h>
#include <windows.h>
#include <vector>
const int size1 =200;
const int size2 =200;

using namespace sf;
using namespace std;

struct gen {
	short int type;
	short int life_time;
	short int eat_amount;
	
};

struct cell {
	short int color[3];
	short int strange;
	gen geno;
	short int time;
	short int rotation;

}; 
void VecToR1R2(int vec,int* r1,int* r2) {
	if (vec == 0) *r1 = 0, *r2 = 1;
	if (vec == 1) *r1 = 1, *r2 = 0;
	if (vec == 3) *r1 = -1, *r2 = 0;
	if (vec == 4) *r1 = 0, *r2 = -1;


}

int R1R2ToVec(int i , int j,int p1, int p2) 
{
	int r1 = p1 - i;
	int r2 = p2 - j;
	if (r1 == 0 && r2 == 1)return 0;
	if (r1 == 1 && r2 == 0)return 1;
	if (r1 == 0 && r2 == -1) return 2;
	if (r1 == -1 && r2 == 0) return 3;
}
void VecToRot(int vec, short int * rot) {
	//sprite.setRotation(90.f);
	if (vec == 0) *rot = 90;
	if (vec == 1) *rot = 0;
	if (vec == 3) *rot = -90;
	if (vec == 4) *rot = 180;



}
float distance(int x1, int y1, int x2, int y2)
{
	return sqrt(pow(x2 - x1, 2) +
		pow(y2 - y1, 2) * 1.0);
}
bool check(cell **matrix, int p1, int p2) {
	if (p1 >= 0 && p2 >= 0 && p1 < size1 && p2 < size2 && matrix[p1][p2].geno.type == 0)
		return 0;
	return 1;
}
bool check_space(cell **matrix, int p1, int p2){
	int c = 0;
	for (int z1 = -1; z1 != 2; z1++) {
		for (int z2 = -1; z2 != 2; z2++) {
			if (check(matrix,z1+p1,z2+p2)==0 )
				c++;
		}
		
	}
	if(c <=4)return 0;
	return 1;

}
void clone(cell donorcell, cell* clone) {
	clone->geno.type = donorcell.geno.type;
	clone->geno.eat_amount = donorcell.geno.eat_amount;
	clone->strange = donorcell.strange;
	clone->time = donorcell.geno.life_time;

	clone->geno.life_time = donorcell.geno.life_time;
	for (int i = 0; i < 3; i++)
		clone->color[i] = donorcell.color[i];

}
void clone(cell donorcell, cell* clone, int r, int g, int b) {
	clone->geno.type = donorcell.geno.type;
	clone->strange = donorcell.strange;
	clone->geno.eat_amount = donorcell.geno.eat_amount;
	clone->time = donorcell.geno.life_time;
	clone->geno.life_time = donorcell.geno.life_time;

	clone->color[0] = r;
	clone->color[1] = g;
	clone->color[2] = b;
}
void kill(cell* cell) {
	cell->geno.type = 0;
	cell->geno.life_time = 0;
	cell->geno.eat_amount = 0;
	cell->strange = 0;

	cell->time = -1;
	for (int i = 0; i < 3; i++)
		cell->color[i] = 0;
}
void move(cell* donorcell, cell* clone) {
	clone->geno.type = donorcell->geno.type;
	clone->strange = donorcell->strange;
	clone->geno.eat_amount = donorcell->geno.eat_amount;
	clone->time = donorcell->time;
	clone->geno.life_time = donorcell->geno.life_time;

	for (int i = 0; i < 3; i++)
		clone->color[i] = donorcell->color[i];
	kill(donorcell);
}
void new_trash(cell* cell) {
	cell->geno.type = 3;
	cell->strange = 0;
	cell->time = -1; 
	cell->color[0] = 175 + rand()%50-25;
	cell->color[1] = 181 + rand() % 50 - 25;
	cell->color[2] = 118 + rand() % 50 - 25;
}

void rand_rot(cell* cell) {
	cell->rotation = cell->rotation + rand() % 11 - 5;

}

int brain_move(int i ,int j, cell **matrix,int type) {
	int vec = -1;
	int eat_type;
	if (type == 2)eat_type = 1;
	else if (type == 4)eat_type = 3;
	else if (type == 5)eat_type = 2;
	int s1 =0 , s2=0;
	float shortest = -1;
	
	for (int p1 = -4; p1 < 5; p1++) {
		for (int p2 = -4; p2 < 5; p2++) {
			
			if(p1 == 0 || p2 ==0)
			if (check(matrix, p1 + i, j+p2) == 0 && matrix[i + p1][j + p2].geno.type == eat_type)
			{
				if (shortest == -1) { shortest = distance(i, j, p1 + i, j + p2); s1 = p1, s2 =p2; }
				if (distance(i, j, p1 + i, j + p2) < shortest) {
					shortest = distance(i, j, p1 + i, j + p2);
					s1 = p1; s2 = p2;
				}
			}

		}
	}
    if (s1 < 0 && s2 > 0)/*if (rand() % 2 == 0)vec = 3; else*/ vec = 1;
	else if (s1 > 0 && s2 > 0)/*if (rand() % 2 == 0)vec = 2; else*/ vec = 1;
	else if (s1 > 0 && s2 < 0)/*if (rand() % 2 == 0)vec = 2; else*/ vec = 4;
	else if (s1 < 0 && s2 < 0)/*if (rand() % 2 == 0)vec = 3; else*/ vec = 4;
	else if (s1 == 0 && s2 > 0)vec = 1;
	else if (s1 > 0 && s2 == 0)vec = 2;
	else if (s1 < 0 && s2 == 0)vec = 3;
	else if (s1 == 0 && s2 < 0)vec = 4;
   if (vec != -1)return vec;
	return -1;



}
void display(cell **matrix, int size1, int size2, RenderWindow& window, int wheel, int x, int y, int res, Event event, Texture cell, Texture cell2,Texture cell3, Texture cell4,Texture cell5 )
{


	if (event.type == Event::Closed) {
		window.close();
		std::terminate();
	}



	window.clear(Color(237, 230, 234, 0));
	int mashtab = res / size1;// (size1 / 0.9142857142857143) + wheel; //* 1.11;
	double size= 0.20;
	for (int i = 0; i < size1; i++) {
		for (int j = 0; j < size2; j++) {
			
			if (matrix[i][j].time > 0|| matrix[i][j].geno.type==1 || matrix[i][j].geno.type == 3) {
				Sprite sprite;
				if(matrix[i][j].geno.type == 2|| matrix[i][j].geno.type == 4|| matrix[i][j].geno.type == 5)
			    sprite.setOrigin(sf::Vector2f(50.f, 50.f));

				sprite.setTexture(cell);
				if (matrix[i][j].geno.type == 1)
				sprite.setTexture(cell2);
				if (matrix[i][j].geno.type == 3)
					sprite.setTexture(cell3);
                if (matrix[i][j].geno.type == 4)
					sprite.setTexture(cell4);
				if (matrix[i][j].geno.type == 5)
					sprite.setTexture(cell5);
				
				sprite.setScale(sf::Vector2f(size, size));
				
				sprite.setColor(Color(matrix[i][j].color[0], matrix[i][j].color[1], matrix[i][j].color[2],128));
				sprite.rotate(matrix[i][j].rotation);
				sprite.move((mashtab * i) + x, ((mashtab * j) + y));
				window.draw(sprite);
			}
		}
	}
}
RectangleShape addPixel(sf::Vector2f position, sf::Uint8 red, sf::Uint8 green, sf::Uint8 blue)
{
	sf::RectangleShape pixel;
	pixel.setSize({ 1.f, 1.f });
	pixel.setFillColor({ red, green, blue });
	pixel.setPosition(position);
	return pixel;
}
void to_proc(int &a,int proc) {
	a = a / 100 * proc;
}

int main()
{
	//inizial

	srand(time(0));
	cell** matrix = new cell * [size1];
	for (int i = 0; i < size1; i++)
		matrix[i] = new cell[size2];

	int counts = 2;
	int tempcount = 0;
	int c = 0;
	int r1, r2;
	int temps;
	int temp;
	int tempchar = 0;

	int wheel = 0;
	int x = 0, y = 0;
	int wtime = 0;
	int fre = 0;
	int soundMode = 0;
	float cameraMovementSpeed = 30;
	int maxPop = 700;
	int res = 1000;
	int mashtab;
	int temp2;

	
	//start
	for (int i = 0; i < size1; i++)
		for (int j = 0; j < size2; j++) {
			matrix[i][j].geno.type = 0;
			matrix[i][j].strange = 0;
			matrix[i][j].time = 0;
			matrix[i][j].rotation = 0;
			matrix[i][j].geno.life_time = 0;
		
		}





	//first gen
	for (int i = 0; i < 500; i++) {
		int fi = rand() % size1;
		int fj = rand() % size1;

		if (check(matrix, fi, fj) == 0) {
			matrix[fi][fj].geno.type = 1;
			matrix[fi][fj].strange = 1;

			matrix[fi][fj].geno.life_time = -1;
			matrix[fi][fj].time = matrix[fi][fj].geno.life_time;
			matrix[fi][fj].rotation = rand() % 180;
			matrix[fi][fj].color[0] = 87;
			matrix[fi][fj].color[1] = 200 - rand() % 20;
			matrix[fi][fj].color[2] = 67;
		}
	}


	for (int i = 0; i < 10; i++) {
		int fi = rand() % size1;
		int fj = rand() % size1;

		matrix[fi][fj].geno.type = 2;
		matrix[fi][fj].geno.eat_amount =100;
		matrix[fi][fj].strange = 1;
		matrix[fi][fj].geno.life_time = 100;
		matrix[fi][fj].rotation = rand() % 180;
		matrix[fi][fj].time = matrix[fi][fj].geno.life_time;
		matrix[fi][fj].color[0] = 111;
		matrix[fi][fj].color[1] = 140;
		matrix[fi][fj].color[2] = 240 - rand() % 10;
	}
	for (int i = 0; i < 15; i++) {
		int fi = rand() % size1;
		int fj = rand() % size1;

		if (check(matrix, fi, fj) == 0) {

			matrix[fi][fj].geno.type = 4;
			matrix[fi][fj].geno.eat_amount =600;
			matrix[fi][fj].strange = 1;
			matrix[fi][fj].geno.life_time = 600;
			matrix[fi][fj].rotation = rand() % 180;
			matrix[fi][fj].time = matrix[fi][fj].geno.life_time;
			matrix[fi][fj].color[0] = 14;
			matrix[fi][fj].color[1] = 227;
			matrix[fi][fj].color[2] = 235 - rand() % 20;
		}
	}
	for (int i = 0; i <10; i++) {
		int fi = rand() % size1;
		int fj = rand() % size1;
		if (check(matrix, fi, fj) == 0) {
			matrix[fi][fj].geno.type = 5;
			matrix[fi][fj].strange = 1;
			matrix[fi][fj].geno.eat_amount = 600;
			matrix[fi][fj].geno.life_time = 600;
			matrix[fi][fj].time = matrix[fi][fj].geno.life_time;
			matrix[fi][fj].color[0] = 255;
			matrix[fi][fj].color[1] = 0;
			matrix[fi][fj].color[2] = 0;
		}
	} 


	RectangleShape back(sf::Vector2f(res + 610, res-400));
	back.setFillColor(sf::Color(255, 255, 255));
	back.move(res, 100);
	RenderWindow window(VideoMode(res + 610, res), "MicroEcoSystem v.1");
	std::vector<sf::RectangleShape> pixels;
	Texture cell;
	window.setFramerateLimit(15);
	if (!cell.loadFromFile("cell.png"))
	{
		std::cout << "Missing cell.png\n";
	}
	cell.setSmooth(true);

	Texture cell2;
	if (!cell2.loadFromFile("cell2.png"))
	{
		std::cout << "Missing cell2.png\n";
	}
	cell2.setSmooth(true);

	Texture cell3;
	if (!cell3.loadFromFile("cell3.png"))
	{
		std::cout << "Missing cell3.png\n";
	}
	cell3.setSmooth(true);
	Texture cell4;
	if (!cell4.loadFromFile("cell4.png"))
	{
		std::cout << "Missing cell4.png\n";
	}
	cell4.setSmooth(true);
	Texture cell5;
	if (!cell5.loadFromFile("cell5.png"))
	{
		std::cout << "Missing cell5.png\n";
	}
	cell5.setSmooth(true);


	int res_am  =4;

	Font font;
	font.loadFromFile("ubuntu.ttf");
	VertexArray pointmap(Points, 400 * 10);
	while (window.isOpen())
	{


		Event event;
		while (window.pollEvent(event))
		{

			if (event.type == Event::Closed) {
				window.close();
				return 0;
			}

			else if (Keyboard::isKeyPressed(Keyboard::C))
			{
				while (Keyboard::isKeyPressed(Keyboard::V) == 0) {


				}

			}
			else if (Keyboard::isKeyPressed(Keyboard::P))
			{
				int fi = rand() % size1;
				int fj = rand() % size1;

				matrix[fi][fj].geno.type = 2;
				matrix[fi][fj].geno.eat_amount = 100;
				matrix[fi][fj].strange = 1;
				matrix[fi][fj].geno.life_time = 100;
				matrix[fi][fj].rotation = rand() % 180;
				matrix[fi][fj].time = matrix[fi][fj].geno.life_time;
				matrix[fi][fj].color[0] = 111;
				matrix[fi][fj].color[1] = 140;
				matrix[fi][fj].color[2] = 240 - rand() % 10;

			}
			else if (Keyboard::isKeyPressed(Keyboard::O))
			{
				int fi = rand() % size1;
				int fj = rand() % size1;

				if (check(matrix, fi, fj) == 0) {
					matrix[fi][fj].geno.type = 4;
					matrix[fi][fj].geno.eat_amount = 600;
					matrix[fi][fj].strange = 1;
					matrix[fi][fj].geno.life_time = 600;
					matrix[fi][fj].rotation = rand() % 180;
					matrix[fi][fj].time = matrix[fi][fj].geno.life_time;
					matrix[fi][fj].color[0] = 14;
					matrix[fi][fj].color[1] = 227;
					matrix[fi][fj].color[2] = 235 - rand() % 20;
				}

			}
			else if (Keyboard::isKeyPressed(Keyboard::I))
			{
				int fi = rand() % size1;
				int fj = rand() % size1;

				matrix[fi][fj].geno.type = 5;
				matrix[fi][fj].strange = 1;
				matrix[fi][fj].geno.eat_amount = 300;
				matrix[fi][fj].geno.life_time = 600;
				matrix[fi][fj].time = matrix[fi][fj].geno.life_time;
				matrix[fi][fj].color[0] = 255;
				matrix[fi][fj].color[1] = 0;
				matrix[fi][fj].color[2] = 0;

			}
			else if (Keyboard::isKeyPressed(Keyboard::W))
			{
				res_am++;

			}

			else if (Keyboard::isKeyPressed(Keyboard::S))
			{
				res_am--;

			}


		}
        display(matrix, size1, size2, window, wheel, x, y, res, event, cell, cell2, cell3, cell4, cell5);
		
			for (int i = 0; i < size1; i++)
				for (int j = 0; j < size2; j++) 
					rand_rot(&matrix[i][j]);
					
		
		
		
		//time kill
		for (int i = 0; i < size1; i++)
			for (int j = 0; j < size2; j++) {
				
				if (matrix[i][j].time)matrix[i][j].time--;
				else if (matrix[i][j].geno.type > 0 && matrix[i][j].time == 0&& matrix[i][j].geno.type!= 4) { kill(&matrix[i][j]); if (matrix[i][j].geno.type != 4)new_trash(&matrix[i][j]); }

			}
		//resources
		for (int i = 0; i < res_am; i++) {
			int fi = rand() % size1;
			int fj = rand() % size1;
			if (check(matrix, fi, fj) == 0) {
				matrix[fi][fj].geno.type = 1;
				matrix[fi][fj].strange = 1;
	
				matrix[fi][fj].geno.life_time = -1;
				matrix[fi][fj].time = matrix[fi][fj].geno.life_time;
				matrix[fi][fj].color[0] = 67;
				matrix[fi][fj].color[1] = 180 - rand() % 20;
				matrix[fi][fj].color[2] = 47;
			}
		}
		//moving
		for (int i = 0; i < size1; i++)
			for (int j = 0; j < size2; j++) {
				rand_rot(&matrix[i][j]);
				if (matrix[i][j].geno.type == 2 || matrix[i][j].geno.type == 4 || matrix[i][j].geno.type == 5) {
					if (rand() % 20 == 0&& matrix[i][j].geno.type!=5) break;
					if (check_space(matrix, i, j) == 0) {
						kill(&matrix[i][j]);	
					}
					else {
						r1 = 0, r2 = 0;
						int vec;
						vec =brain_move(i,j,matrix,matrix[i][j].geno.type);
						VecToR1R2(vec, &r1, &r2);
						while (check(matrix, i + r1, j + r2)) {
							vec = rand() % 5;
							VecToR1R2(vec, &r1, &r2);
							
							
						};
						
						move(&matrix[i][j], &matrix[i + r1][j + r2]);
					}
				}
			}
		//time++ for type2
		for (int i = 0; i < size1; i++)
			for (int j = 0; j < size2; j++) {
				if (matrix[i][j].geno.type == 2) {
					c = 0;
					for (int p1 = -4; p1 < 5; p1++) {
						for (int p2 = -4; p2 < 5; p2++)
						{

							if (p1 + i >= 0 && p2 + j >= 0 && p1 + i < size1 && p2 + j < size2 && matrix[i + p1][j + p2].geno.type == 1)
							{
								c++;
								kill(&matrix[i + p1][j + p2]);
							}


						}
					}
					if (c) { matrix[i][j].time = +c * matrix[i][j].geno.eat_amount; }

				}
			
		//time++ for type 4
		
				if (matrix[i][j].geno.type == 4) {
					c = 0;
					for (int p1 = -4; p1 < 5; p1++) {
						for (int p2 = -4; p2 < 5; p2++)
						{

							if (p1 + i >= 0 && p2 + j >= 0 && p1 + i < size1 && p2 + j < size2 && matrix[i + p1][j + p2].geno.type == 3)
							{
								c++;
								kill(&matrix[i + p1][j + p2]);
							}


						}
					}
					if (c) { matrix[i][j].time = +c * matrix[i][j].geno.eat_amount; }

			}
			
		//time++ for type 5
		
				if (matrix[i][j].geno.type == 5) {
					c = 0;
					for (int p1 = -5; p1 <6; p1++) {
						for (int p2 = -5; p2 < 6; p2++)
						{

							if (p1 + i >= 0 && p2 + j >= 0 && p1 + i < size1 && p2 + j < size2 &&matrix[i + p1][j + p2].geno.type == 2 ) /*|| p1 + i >= 0 && p2 + j >= 0 && p1 + i < size1 && p2 + j < size2 && matrix[i + p1][j + p2].geno.type == 4 )*/
							{
								c++;
								kill(&matrix[i + p1][j + p2]);
							}


						}
					}
					if (c) { matrix[i][j].time = +c * matrix[i][j].geno.eat_amount; }

				}
			}
		
		//++

		for (int i = 0; i < size1; i++)
			for (int j = 0; j < size2; j++) {
				
				if (matrix[i][j].geno.type == 2 && matrix[i][j].time >= matrix[i][j].geno.eat_amount*2  || matrix[i][j].geno.type == 4 && matrix[i][j].time >= matrix[i][j].geno.eat_amount*2 - 200 || matrix[i][j].geno.type == 5 && matrix[i][j].time >= matrix[i][j].geno.eat_amount*2 ) {
					if (check_space(matrix, i, j) == 0) {
						//kill(&matrix[i][j]); new_trash(&matrix[i][j]);
					}
					else {



						r1 = 0, r2 = 0;
						int vec = rand() % 5;
						VecToR1R2(vec, &r1, &r2);
						
						while (check(matrix, i + r1, j + r2)) {
							vec = rand() % 5;
							VecToR1R2(vec, &r1, &r2);
							
						};
 
						clone(matrix[i][j], &matrix[i + r1][j + r2]);
				

					}

				}
			}
		//spactate
		temp = 0;
		temp2 = 0;
		int temp3 = 0;
		int temp4 = 0;
		for (int i = 0; i < size1; i++)
			for (int j = 0; j < size2; j++) {
				if (matrix[i][j].geno.type == 2)
					temp++;

				if (matrix[i][j].geno.type == 1)
					temp2++;
				if (matrix[i][j].geno.type == 4)
					temp3++;
				if (matrix[i][j].geno.type == 5)
					temp4++;
			}
		fre = +temp;

		string text1t;
		char num1[4];
		text1t = " - ";
		_itoa(temp, num1, 10);
		text1t = text1t + num1;
		Text text(text1t, font, 20);
		text.setFillColor(Color::Black);
		text.setPosition(res +100, 650);
		window.draw(text);
		Sprite sprite;
		sprite.setTexture(cell);
		sprite.setScale(sf::Vector2f(0.5, 0.5));
		/*if (matrix[i][j].geno.type == 5) { sprite.setScale(sf::Vector2f(size + 00.1, size + 00.2)); sprite.setOrigin(sf::Vector2f(70.f, 70.f));
		}*/
		sprite.setColor(Color(11,140,240,128));
		sprite.move(res+40,630);
		window.draw(sprite);

		string text2t;
		char num2[4];
		text2t = " - ";
		_itoa(temp3, num2, 10);
		text2t = text2t + num2;
		Text text2(text2t, font, 20);
		text2.setFillColor(Color::Black);
		text2.setPosition(res + 100, 750);
		window.draw(text2);
		Sprite sprite2;
		sprite2.setTexture(cell4);
		sprite2.setScale(sf::Vector2f(0.5, 0.5));
		/*if (matrix[i][j].geno.type == 5) { sprite.setScale(sf::Vector2f(size + 00.1, size + 00.2)); sprite.setOrigin(sf::Vector2f(70.f, 70.f));
		}*/
		sprite2.setColor(Color(14,227,225, 128));
		sprite2.move(res + 40, 730);
		window.draw(sprite2);

		string text3t;
		char num3[4];
		text3t = " - ";
		_itoa(temp4, num3, 10);
		text3t = text3t + num3;
		Text text3(text3t, font, 20);
		text3.setFillColor(Color::Black);
		text3.setPosition(res + 100,850);
		window.draw(text3);
		Sprite sprite3;
		sprite3.setTexture(cell5);
		sprite3.setScale(sf::Vector2f(0.5, 0.5));
		/*if (matrix[i][j].geno.type == 5) { sprite.setScale(sf::Vector2f(size + 00.1, size + 00.2)); sprite.setOrigin(sf::Vector2f(70.f, 70.f));
		}*/
		sprite3.setColor(Color(255,0,0, 128));
		sprite3.move(res + 40, 830);
		window.draw(sprite3);

		string text4t;
		char num4[4];
		text4t = "Light - ";
		_itoa(res_am, num4, 10);
		text4t = text4t + num4;
		Text text4(text4t, font, 20);
		text4.setFillColor(Color::Black);
		text4.setPosition(res + 300, 650);
		window.draw(text4);

		if (wtime / 10 < 610) {
			Vector2f px(res + wtime / 10, 400 + (temp / 4) * -1);
			pixels.push_back(addPixel(px, 0,0,255));
			Vector2f px2(res+ wtime / 10, 500 + (temp2 / 4) * -1);
			pixels.push_back(addPixel(px2, 17, 207, 74));
			Vector2f px3(res+ wtime / 10, 550 + (temp3 / 4) * -1);
			pixels.push_back(addPixel(px3, 4, 151, 184));
			Vector2f px4(res + wtime / 10, 600 + (temp4 / 4) * -1);
			pixels.push_back(addPixel(px4, 196, 10, 41));
		}
		



        //window.draw(back);
		
		for (const auto& pixel : pixels)
		{
			window.draw(pixel);
		}
		
		window.display();

		wtime++;


	}
	return 0;

}



